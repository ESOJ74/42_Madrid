#/bin/sh
ifconfig | awk '{if ($1 == "ether") {print $2}}'
