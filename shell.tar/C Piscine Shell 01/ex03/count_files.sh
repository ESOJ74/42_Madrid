#/bin/sh
find . | wc -l | bc
